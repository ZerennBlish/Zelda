public interface IStunnable
{
    void Stun(float duration);
}